// Spotify API integration utilities
// Note: Users need to set up Spotify API credentials

export interface SpotifyTrack {
  id: string
  name: string
  artists: { name: string }[]
  preview_url: string | null
  external_urls: { spotify: string }
}

export interface SpotifyPlaylist {
  id: string
  name: string
  description: string
  tracks: { items: { track: SpotifyTrack }[] }
}

class SpotifyAPI {
  private accessToken: string | null = null
  private clientId: string
  private clientSecret: string

  constructor() {
    // In a real app, these would come from environment variables
    this.clientId = process.env.NEXT_PUBLIC_SPOTIFY_CLIENT_ID || ""
    this.clientSecret = process.env.SPOTIFY_CLIENT_SECRET || ""
  }

  async getAccessToken(): Promise<string> {
    if (this.accessToken) return this.accessToken

    const response = await fetch("https://accounts.spotify.com/api/token", {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
        Authorization: `Basic ${btoa(`${this.clientId}:${this.clientSecret}`)}`,
      },
      body: "grant_type=client_credentials",
    })

    const data = await response.json()
    this.accessToken = data.access_token
    return this.accessToken
  }

  async searchPlaylists(query: string): Promise<SpotifyPlaylist[]> {
    const token = await this.getAccessToken()

    const response = await fetch(
      `https://api.spotify.com/v1/search?q=${encodeURIComponent(query)}&type=playlist&limit=10`,
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      },
    )

    const data = await response.json()
    return data.playlists?.items || []
  }

  async getPlaylistTracks(playlistId: string): Promise<SpotifyTrack[]> {
    const token = await this.getAccessToken()

    const response = await fetch(`https://api.spotify.com/v1/playlists/${playlistId}/tracks`, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })

    const data = await response.json()
    return data.items?.map((item: any) => item.track) || []
  }

  async createContraryPlaylist(mood: string, userId: string): Promise<SpotifyPlaylist | null> {
    // This would create a custom playlist based on the detected mood
    // Implementation depends on Spotify Web API and user authentication
    console.log(`Creating contrary playlist for mood: ${mood}`)
    return null
  }
}

export const spotifyAPI = new SpotifyAPI()
