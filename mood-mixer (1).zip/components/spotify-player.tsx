"use client"

import { useState, useEffect } from "react"
import { Play, Pause, SkipForward, SkipBack, Volume2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Slider } from "@/components/ui/slider"
import { Card, CardContent } from "@/components/ui/card"

interface SpotifyPlayerProps {
  accessToken: string
  onDeviceReady: (deviceId: string) => void
}

declare global {
  interface Window {
    onSpotifyWebPlaybackSDKReady: () => void
    Spotify: any
  }
}

export function SpotifyPlayer({ accessToken, onDeviceReady }: SpotifyPlayerProps) {
  const [player, setPlayer] = useState<any>(null)
  const [deviceId, setDeviceId] = useState<string>("")
  const [currentTrack, setCurrentTrack] = useState<any>(null)
  const [isPlaying, setIsPlaying] = useState(false)
  const [volume, setVolume] = useState([50])
  const [position, setPosition] = useState(0)
  const [duration, setDuration] = useState(0)
  const [isReady, setIsReady] = useState(false)

  useEffect(() => {
    if (!accessToken) return

    // Load Spotify Web Playback SDK
    const script = document.createElement("script")
    script.src = "https://sdk.scdn.co/spotify-player.js"
    script.async = true
    document.body.appendChild(script)

    window.onSpotifyWebPlaybackSDKReady = () => {
      const spotifyPlayer = new window.Spotify.Player({
        name: "Mood Mixer Player",
        getOAuthToken: (cb: (token: string) => void) => {
          cb(accessToken)
        },
        volume: 0.5,
      })

      // Error handling
      spotifyPlayer.addListener("initialization_error", ({ message }: any) => {
        console.error("Spotify initialization error:", message)
      })

      spotifyPlayer.addListener("authentication_error", ({ message }: any) => {
        console.error("Spotify authentication error:", message)
      })

      spotifyPlayer.addListener("account_error", ({ message }: any) => {
        console.error("Spotify account error:", message)
      })

      spotifyPlayer.addListener("playback_error", ({ message }: any) => {
        console.error("Spotify playback error:", message)
      })

      // Playback status updates
      spotifyPlayer.addListener("player_state_changed", (state: any) => {
        if (!state) return

        setCurrentTrack(state.track_window.current_track)
        setIsPlaying(!state.paused)
        setPosition(state.position)
        setDuration(state.duration)
      })

      // Ready
      spotifyPlayer.addListener("ready", ({ device_id }: { device_id: string }) => {
        console.log("Spotify player ready with Device ID", device_id)
        setDeviceId(device_id)
        setIsReady(true)
        onDeviceReady(device_id)
      })

      // Not Ready
      spotifyPlayer.addListener("not_ready", ({ device_id }: { device_id: string }) => {
        console.log("Spotify player not ready with Device ID", device_id)
        setIsReady(false)
      })

      // Connect to the player
      spotifyPlayer.connect().then((success: boolean) => {
        if (success) {
          console.log("Successfully connected to Spotify!")
          setPlayer(spotifyPlayer)
        }
      })
    }

    return () => {
      if (player) {
        player.disconnect()
      }
    }
  }, [accessToken, onDeviceReady])

  const togglePlay = () => {
    if (player) {
      player.togglePlay()
    }
  }

  const skipToNext = () => {
    if (player) {
      player.nextTrack()
    }
  }

  const skipToPrevious = () => {
    if (player) {
      player.previousTrack()
    }
  }

  const setPlayerVolume = (newVolume: number[]) => {
    setVolume(newVolume)
    if (player) {
      player.setVolume(newVolume[0] / 100)
    }
  }

  const formatTime = (ms: number) => {
    const minutes = Math.floor(ms / 60000)
    const seconds = Math.floor((ms % 60000) / 1000)
    return `${minutes}:${seconds.toString().padStart(2, "0")}`
  }

  if (!isReady) {
    return (
      <Card>
        <CardContent className="p-4">
          <div className="text-center text-gray-600">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-green-500 mx-auto mb-2"></div>
            <p>Initializing Spotify Player...</p>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className="bg-gray-900 text-white">
      <CardContent className="p-4 space-y-4">
        {currentTrack && (
          <div className="flex items-center gap-4">
            <img
              src={currentTrack.album.images[0]?.url || "/placeholder.svg"}
              alt={currentTrack.album.name}
              className="w-16 h-16 rounded-lg"
            />
            <div className="flex-1 min-w-0">
              <p className="font-medium truncate">{currentTrack.name}</p>
              <p className="text-sm text-gray-400 truncate">
                {currentTrack.artists.map((a: any) => a.name).join(", ")}
              </p>
              <p className="text-xs text-gray-500 truncate">{currentTrack.album.name}</p>
            </div>
          </div>
        )}

        <div className="flex items-center justify-center gap-4">
          <Button onClick={skipToPrevious} size="sm" variant="ghost" className="text-white hover:text-green-400">
            <SkipBack className="w-5 h-5" />
          </Button>

          <Button onClick={togglePlay} size="lg" className="bg-green-500 hover:bg-green-600 rounded-full">
            {isPlaying ? <Pause className="w-6 h-6" /> : <Play className="w-6 h-6" />}
          </Button>

          <Button onClick={skipToNext} size="sm" variant="ghost" className="text-white hover:text-green-400">
            <SkipForward className="w-5 h-5" />
          </Button>
        </div>

        <div className="space-y-2">
          <div className="flex items-center gap-2 text-xs text-gray-400">
            <span>{formatTime(position)}</span>
            <div className="flex-1 bg-gray-700 rounded-full h-1">
              <div
                className="bg-green-500 h-1 rounded-full transition-all"
                style={{ width: `${duration ? (position / duration) * 100 : 0}%` }}
              />
            </div>
            <span>{formatTime(duration)}</span>
          </div>

          <div className="flex items-center gap-2">
            <Volume2 className="w-4 h-4 text-gray-400" />
            <Slider value={volume} onValueChange={setPlayerVolume} max={100} min={0} step={1} className="flex-1" />
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
