"use client"

import { useState, useRef, useEffect } from "react"
import { Play, Pause, Volume2, VolumeX } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Slider } from "@/components/ui/slider"

interface AudioPlayerProps {
  trackName: string
  isPlaying: boolean
  onPlayPause: () => void
}

export function AudioPlayer({ trackName, isPlaying, onPlayPause }: AudioPlayerProps) {
  const [volume, setVolume] = useState([50])
  const [isMuted, setIsMuted] = useState(false)
  const [currentTime, setCurrentTime] = useState(0)
  const [duration, setDuration] = useState(0)
  const audioRef = useRef<HTMLAudioElement>(null)

  // Sample audio URLs for different moods (you can replace with real tracks)
  const sampleTracks: Record<string, string> = {
    Happy: "/placeholder-audio.mp3", // You'll need to add actual audio files
    Upbeat: "/placeholder-audio.mp3",
    Chill: "/placeholder-audio.mp3",
    Peaceful: "/placeholder-audio.mp3",
    Energetic: "/placeholder-audio.mp3",
  }

  const getSampleTrack = (trackName: string) => {
    const genre = trackName.split(" ")[0]
    return sampleTracks[genre] || "/placeholder-audio.mp3"
  }

  useEffect(() => {
    const audio = audioRef.current
    if (!audio) return

    const updateTime = () => setCurrentTime(audio.currentTime)
    const updateDuration = () => setDuration(audio.duration)

    audio.addEventListener("timeupdate", updateTime)
    audio.addEventListener("loadedmetadata", updateDuration)

    return () => {
      audio.removeEventListener("timeupdate", updateTime)
      audio.removeEventListener("loadedmetadata", updateDuration)
    }
  }, [])

  useEffect(() => {
    const audio = audioRef.current
    if (!audio) return

    if (isPlaying) {
      audio.play().catch(console.error)
    } else {
      audio.pause()
    }
  }, [isPlaying])

  useEffect(() => {
    const audio = audioRef.current
    if (!audio) return

    audio.volume = isMuted ? 0 : volume[0] / 100
  }, [volume, isMuted])

  const formatTime = (time: number) => {
    const minutes = Math.floor(time / 60)
    const seconds = Math.floor(time % 60)
    return `${minutes}:${seconds.toString().padStart(2, "0")}`
  }

  return (
    <div className="p-4 bg-gray-900 text-white rounded-lg space-y-3">
      <audio ref={audioRef} src={getSampleTrack(trackName)} loop preload="metadata" />

      <div className="flex items-center justify-between">
        <div className="flex-1">
          <p className="font-medium truncate">{trackName}</p>
          <p className="text-sm text-gray-400">Mood Mixer Player</p>
        </div>

        <Button onClick={onPlayPause} size="sm" className="bg-green-500 hover:bg-green-600">
          {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
        </Button>
      </div>

      <div className="space-y-2">
        <div className="flex items-center gap-2 text-xs text-gray-400">
          <span>{formatTime(currentTime)}</span>
          <div className="flex-1 bg-gray-700 rounded-full h-1">
            <div
              className="bg-green-500 h-1 rounded-full transition-all"
              style={{ width: `${duration ? (currentTime / duration) * 100 : 0}%` }}
            />
          </div>
          <span>{formatTime(duration)}</span>
        </div>

        <div className="flex items-center gap-2">
          <Button onClick={() => setIsMuted(!isMuted)} size="sm" variant="ghost" className="p-1 h-auto">
            {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
          </Button>
          <Slider value={volume} onValueChange={setVolume} max={100} min={0} step={1} className="flex-1" />
        </div>
      </div>
    </div>
  )
}
