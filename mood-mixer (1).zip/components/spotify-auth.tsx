"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Music, CheckCircle } from "lucide-react"

interface SpotifyAuthProps {
  onAuthSuccess: (tokens: { accessToken: string; refreshToken: string; expiresIn: number }) => void
}

export function SpotifyAuth({ onAuthSuccess }: SpotifyAuthProps) {
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [userProfile, setUserProfile] = useState<any>(null)
  const [isLoading, setIsLoading] = useState(false)

  useEffect(() => {
    // Check for tokens in URL (from OAuth redirect)
    const urlParams = new URLSearchParams(window.location.search)
    const accessToken = urlParams.get("access_token")
    const refreshToken = urlParams.get("refresh_token")
    const expiresIn = urlParams.get("expires_in")

    if (accessToken && refreshToken && expiresIn) {
      // Clean up URL
      window.history.replaceState({}, document.title, window.location.pathname)

      // Store tokens and notify parent
      const tokens = {
        accessToken,
        refreshToken,
        expiresIn: Number.parseInt(expiresIn),
      }

      localStorage.setItem("spotify_tokens", JSON.stringify(tokens))
      onAuthSuccess(tokens)
      setIsAuthenticated(true)
      fetchUserProfile(accessToken)
    } else {
      // Check for stored tokens
      const storedTokens = localStorage.getItem("spotify_tokens")
      if (storedTokens) {
        const tokens = JSON.parse(storedTokens)
        onAuthSuccess(tokens)
        setIsAuthenticated(true)
        fetchUserProfile(tokens.accessToken)
      }
    }
  }, [onAuthSuccess])

  const fetchUserProfile = async (accessToken: string) => {
    try {
      const response = await fetch("https://api.spotify.com/v1/me", {
        headers: {
          Authorization: `Bearer ${accessToken}`,
        },
      })

      if (response.ok) {
        const profile = await response.json()
        setUserProfile(profile)
      }
    } catch (error) {
      console.error("Failed to fetch user profile:", error)
    }
  }

  const handleLogin = () => {
    setIsLoading(true)
    window.location.href = "/api/auth/spotify"
  }

  const handleLogout = () => {
    localStorage.removeItem("spotify_tokens")
    setIsAuthenticated(false)
    setUserProfile(null)
    window.location.reload()
  }

  if (isAuthenticated && userProfile) {
    return (
      <Card className="border-green-200 bg-green-50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-green-800">
            <CheckCircle className="w-5 h-5" />
            Connected to Spotify
          </CardTitle>
          <CardDescription>Ready to play real music!</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center gap-3">
            {userProfile.images?.[0]?.url && (
              <img
                src={userProfile.images[0].url || "/placeholder.svg"}
                alt="Profile"
                className="w-12 h-12 rounded-full"
              />
            )}
            <div>
              <p className="font-medium">{userProfile.display_name}</p>
              <p className="text-sm text-gray-600">{userProfile.email}</p>
            </div>
            <Badge variant="secondary" className="ml-auto">
              {userProfile.product || "Free"}
            </Badge>
          </div>
          <Button onClick={handleLogout} variant="outline" size="sm">
            Disconnect
          </Button>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className="border-orange-200 bg-orange-50">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-orange-800">
          <Music className="w-5 h-5" />
          Connect to Spotify
        </CardTitle>
        <CardDescription>Connect your Spotify account to play real music based on your mood</CardDescription>
      </CardHeader>
      <CardContent>
        <Button onClick={handleLogin} disabled={isLoading} className="w-full bg-green-500 hover:bg-green-600">
          <Music className="w-4 h-4 mr-2" />
          {isLoading ? "Connecting..." : "Connect with Spotify"}
        </Button>
        <p className="text-xs text-gray-600 mt-2">
          You'll be redirected to Spotify to authorize this app. We only request permissions needed for music playback.
        </p>
      </CardContent>
    </Card>
  )
}
