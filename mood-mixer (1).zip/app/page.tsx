"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Camera, Music, Settings, Smile, Frown, Meh, Heart, Zap } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Slider } from "@/components/ui/slider"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { SpotifyAuth } from "@/components/spotify-auth"
import { SpotifyPlayer } from "@/components/spotify-player"

type Mood = {
  name: string
  confidence: number
  icon: React.ReactNode
  color: string
  contraryPlaylist: string[]
}

const moodDatabase = {
  sad: {
    name: "Sad",
    icon: <Frown className="w-6 h-6" />,
    color: "bg-blue-500",
    contraryPlaylist: ["happy", "upbeat", "dance", "pop", "feel good"],
  },
  happy: {
    name: "Happy",
    icon: <Smile className="w-6 h-6" />,
    color: "bg-yellow-500",
    contraryPlaylist: ["chill", "ambient", "relaxing", "meditation", "calm"],
  },
  angry: {
    name: "Angry",
    icon: <Zap className="w-6 h-6" />,
    color: "bg-red-500",
    contraryPlaylist: ["peaceful", "classical", "nature sounds", "spa", "zen"],
  },
  neutral: {
    name: "Neutral",
    icon: <Meh className="w-6 h-6" />,
    color: "bg-gray-500",
    contraryPlaylist: ["energetic", "rock", "electronic", "workout", "motivational"],
  },
  excited: {
    name: "Excited",
    icon: <Heart className="w-6 h-6" />,
    color: "bg-pink-500",
    contraryPlaylist: ["acoustic", "folk", "indie", "soft rock", "mellow"],
  },
}

export default function MoodMixer() {
  const [isDetecting, setIsDetecting] = useState(false)
  const [detectedMood, setDetectedMood] = useState<Mood | null>(null)
  const [cameraActive, setCameraActive] = useState(false)
  const [sensitivity, setSensitivity] = useState([75])
  const [autoPlay, setAutoPlay] = useState(true)
  const [feedback, setFeedback] = useState("")
  const [autoCapture, setAutoCapture] = useState(false)
  const [captureInterval, setCaptureInterval] = useState(10)
  const [countdown, setCountdown] = useState(0)
  const [moodHistory, setMoodHistory] = useState<Mood[]>([])
  const [spotifyTokens, setSpotifyTokens] = useState<any>(null)
  const [deviceId, setDeviceId] = useState<string>("")
  const [currentPlaylist, setCurrentPlaylist] = useState<any>(null)
  const videoRef = useRef<HTMLVideoElement>(null)
  const intervalRef = useRef<NodeJS.Timeout | null>(null)
  const countdownRef = useRef<NodeJS.Timeout | null>(null)

  // Mock facial recognition function
  const detectMood = async (isAutomatic = false) => {
    if (!cameraActive) return

    setIsDetecting(true)

    // Simulate processing time
    await new Promise((resolve) => setTimeout(resolve, 2000))

    // Mock mood detection with random results
    const moods = Object.keys(moodDatabase) as (keyof typeof moodDatabase)[]
    const randomMood = moods[Math.floor(Math.random() * moods.length)]
    const confidence = Math.floor(Math.random() * 30) + 70 // 70-100% confidence

    const mood: Mood = {
      name: moodDatabase[randomMood].name,
      confidence,
      icon: moodDatabase[randomMood].icon,
      color: moodDatabase[randomMood].color,
      contraryPlaylist: moodDatabase[randomMood].contraryPlaylist,
    }

    setDetectedMood(mood)
    setMoodHistory((prev) => [mood, ...prev.slice(0, 9)]) // Keep last 10 moods
    setIsDetecting(false)

    if (autoPlay && spotifyTokens) {
      playContraryPlaylist(mood)
    }

    // Log automatic detection
    if (isAutomatic) {
      console.log(`Auto-detected mood: ${mood.name} (${mood.confidence}% confidence)`)
    }
  }

  const startAutoCapture = () => {
    if (!cameraActive) {
      alert("Please start the camera first")
      return
    }

    setAutoCapture(true)
    setCountdown(captureInterval)

    // Initial detection
    detectMood(true)

    // Start countdown
    countdownRef.current = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          return captureInterval
        }
        return prev - 1
      })
    }, 1000)

    // Start auto-detection interval
    intervalRef.current = setInterval(() => {
      detectMood(true)
    }, captureInterval * 1000)
  }

  const stopAutoCapture = () => {
    setAutoCapture(false)
    setCountdown(0)

    if (intervalRef.current) {
      clearInterval(intervalRef.current)
      intervalRef.current = null
    }

    if (countdownRef.current) {
      clearInterval(countdownRef.current)
      countdownRef.current = null
    }
  }

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true })
      if (videoRef.current) {
        videoRef.current.srcObject = stream
        setCameraActive(true)
      }
    } catch (error) {
      console.error("Error accessing camera:", error)
    }
  }

  const stopCamera = () => {
    if (videoRef.current?.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream
      stream.getTracks().forEach((track) => track.stop())
      setCameraActive(false)
    }
  }

  const playContraryPlaylist = async (mood: Mood) => {
    if (!spotifyTokens || !deviceId) {
      console.log("Spotify not connected or device not ready")
      return
    }

    try {
      // Search for playlists based on contrarian mood
      const searchQuery = mood.contraryPlaylist[0] // Use first contrarian genre
      const response = await fetch(`/api/spotify/playlists?q=${searchQuery}`, {
        headers: {
          Authorization: `Bearer ${spotifyTokens.accessToken}`,
        },
      })

      const data = await response.json()

      if (data.playlists && data.playlists.length > 0) {
        const playlist = data.playlists[0]
        setCurrentPlaylist(playlist)

        // Play the playlist
        const playResponse = await fetch("/api/spotify/play", {
          method: "POST",
          headers: {
            Authorization: `Bearer ${spotifyTokens.accessToken}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            playlistUri: playlist.uri,
            deviceId: deviceId,
          }),
        })

        if (playResponse.ok) {
          console.log(`Playing contrarian playlist: ${playlist.name}`)
        } else {
          console.error("Failed to play playlist")
        }
      }
    } catch (error) {
      console.error("Error playing contrarian playlist:", error)
    }
  }

  const submitFeedback = () => {
    console.log("Feedback submitted:", feedback)
    setFeedback("")
  }

  useEffect(() => {
    return () => {
      stopCamera()
      stopAutoCapture()
    }
  }, [])

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-blue-50 p-4">
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center space-y-2">
          <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
            Mood Mixer
          </h1>
          <p className="text-gray-600">AI-powered mood detection with real Spotify integration</p>
        </div>

        {/* Spotify Authentication */}
        <SpotifyAuth onAuthSuccess={setSpotifyTokens} />

        {/* Spotify Player */}
        {spotifyTokens && <SpotifyPlayer accessToken={spotifyTokens.accessToken} onDeviceReady={setDeviceId} />}

        <Tabs defaultValue="detect" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="detect">Mood Detection</TabsTrigger>
            <TabsTrigger value="customize">Customize</TabsTrigger>
            <TabsTrigger value="feedback">Feedback</TabsTrigger>
          </TabsList>

          <TabsContent value="detect" className="space-y-6">
            {/* Camera Section */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Camera className="w-5 h-5" />
                  Automatic Mood Detection Camera
                  {autoCapture && (
                    <Badge variant="secondary" className="ml-2">
                      Auto-capturing every {captureInterval}s
                    </Badge>
                  )}
                </CardTitle>
                <CardDescription>
                  {autoCapture
                    ? `Automatically analyzing your mood every ${captureInterval} seconds`
                    : "Position your face in the camera frame for mood detection"}
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="relative aspect-video bg-gray-900 rounded-lg overflow-hidden">
                  <video ref={videoRef} autoPlay playsInline muted className="w-full h-full object-cover" />
                  {!cameraActive && (
                    <div className="absolute inset-0 flex items-center justify-center">
                      <div className="text-center text-white">
                        <Camera className="w-16 h-16 mx-auto mb-4 opacity-50" />
                        <p>Camera not active</p>
                      </div>
                    </div>
                  )}
                  {isDetecting && (
                    <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                      <div className="text-center text-white">
                        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-white mx-auto mb-4"></div>
                        <p>Analyzing facial expressions...</p>
                      </div>
                    </div>
                  )}
                  {autoCapture && countdown > 0 && !isDetecting && (
                    <div className="absolute top-4 right-4 bg-black/70 text-white px-3 py-2 rounded-lg">
                      <div className="text-center">
                        <div className="text-2xl font-bold">{countdown}</div>
                        <div className="text-xs">Next capture</div>
                      </div>
                    </div>
                  )}
                  {autoCapture && (
                    <div className="absolute top-4 left-4 bg-red-500 text-white px-2 py-1 rounded-full text-xs flex items-center gap-1">
                      <div className="w-2 h-2 bg-white rounded-full animate-pulse"></div>
                      LIVE
                    </div>
                  )}
                </div>

                <div className="space-y-3">
                  <div className="flex gap-2">
                    {!cameraActive ? (
                      <Button onClick={startCamera} className="flex-1">
                        <Camera className="w-4 h-4 mr-2" />
                        Start Camera
                      </Button>
                    ) : (
                      <Button onClick={stopCamera} variant="outline" className="flex-1 bg-transparent">
                        Stop Camera
                      </Button>
                    )}

                    {!autoCapture ? (
                      <Button
                        onClick={startAutoCapture}
                        disabled={!cameraActive}
                        className="flex-1 bg-green-600 hover:bg-green-700"
                      >
                        <div className="w-4 h-4 mr-2 rounded-full bg-white"></div>
                        Start Auto-Detection
                      </Button>
                    ) : (
                      <Button onClick={stopAutoCapture} variant="destructive" className="flex-1">
                        Stop Auto-Detection
                      </Button>
                    )}
                  </div>

                  {!autoCapture && (
                    <Button
                      onClick={() => detectMood(false)}
                      disabled={!cameraActive || isDetecting}
                      variant="outline"
                      className="w-full"
                    >
                      {isDetecting ? "Detecting..." : "Manual Detection"}
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Mood Results */}
            {detectedMood && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    {detectedMood.icon}
                    Detected Mood: {detectedMood.name}
                  </CardTitle>
                  <CardDescription>Confidence: {detectedMood.confidence}%</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Progress value={detectedMood.confidence} className="w-full" />

                  <div className="space-y-2">
                    <h4 className="font-semibold">Contrarian Playlist Genres:</h4>
                    <div className="flex flex-wrap gap-2">
                      {detectedMood.contraryPlaylist.map((genre, index) => (
                        <Badge key={index} variant="secondary">
                          {genre}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  {currentPlaylist && (
                    <div className="p-4 bg-green-50 rounded-lg border border-green-200">
                      <div className="flex items-center gap-2 text-green-800">
                        <Music className="w-5 h-5" />
                        <span className="font-medium">Playing Contrarian Playlist:</span>
                      </div>
                      <p className="text-green-700 mt-1">{currentPlaylist.name}</p>
                      <p className="text-green-600 text-sm">{currentPlaylist.description}</p>
                    </div>
                  )}

                  <Button
                    onClick={() => playContraryPlaylist(detectedMood)}
                    className="w-full"
                    disabled={!spotifyTokens || !deviceId}
                  >
                    <Music className="w-4 h-4 mr-2" />
                    {!spotifyTokens ? "Connect Spotify First" : "Play Contrarian Playlist"}
                  </Button>
                </CardContent>
              </Card>
            )}

            {moodHistory.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle>Mood History</CardTitle>
                  <CardDescription>Recent mood detections and patterns</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {moodHistory.slice(0, 5).map((mood, index) => (
                      <div key={index} className="flex items-center justify-between p-2 bg-gray-50 rounded-lg">
                        <div className="flex items-center gap-2">
                          {mood.icon}
                          <span className="font-medium">{mood.name}</span>
                        </div>
                        <div className="text-sm text-gray-600">{mood.confidence}% confidence</div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="customize" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Settings className="w-5 h-5" />
                  Customization Settings
                </CardTitle>
                <CardDescription>Adjust mood detection sensitivity and playback preferences</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <Label>Detection Sensitivity: {sensitivity[0]}%</Label>
                  <Slider
                    value={sensitivity}
                    onValueChange={setSensitivity}
                    max={100}
                    min={50}
                    step={5}
                    className="w-full"
                  />
                  <p className="text-sm text-gray-600">Higher sensitivity detects subtle mood changes</p>
                </div>

                <div className="space-y-2">
                  <Label>Auto-Capture Interval: {captureInterval} seconds</Label>
                  <Slider
                    value={[captureInterval]}
                    onValueChange={(value) => setCaptureInterval(value[0])}
                    max={60}
                    min={5}
                    step={5}
                    className="w-full"
                  />
                  <p className="text-sm text-gray-600">How often to automatically detect mood</p>
                </div>

                <div className="flex items-center space-x-2">
                  <Switch id="auto-play" checked={autoPlay} onCheckedChange={setAutoPlay} />
                  <Label htmlFor="auto-play">Auto-play contrarian playlists</Label>
                </div>

                <div className="space-y-4">
                  <h4 className="font-semibold">Custom Mood Mappings</h4>
                  {Object.entries(moodDatabase).map(([key, mood]) => (
                    <div key={key} className="p-4 border rounded-lg space-y-2">
                      <div className="flex items-center gap-2">
                        {mood.icon}
                        <span className="font-medium">{mood.name}</span>
                      </div>
                      <div className="flex flex-wrap gap-1">
                        {mood.contraryPlaylist.map((genre, index) => (
                          <Badge key={index} variant="outline" className="text-xs">
                            {genre}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="feedback" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Feedback & Accuracy</CardTitle>
                <CardDescription>Help us improve mood detection and playlist recommendations</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="feedback">Your Feedback</Label>
                  <Textarea
                    id="feedback"
                    placeholder="Was the mood detection accurate? Did the contrarian playlist help improve your mood? Any suggestions?"
                    value={feedback}
                    onChange={(e) => setFeedback(e.target.value)}
                    rows={4}
                  />
                </div>

                <Button onClick={submitFeedback} className="w-full">
                  Submit Feedback
                </Button>

                <div className="mt-6 p-4 bg-blue-50 rounded-lg">
                  <h4 className="font-semibold text-blue-900 mb-2">How It Works</h4>
                  <ul className="text-sm text-blue-800 space-y-1">
                    <li>• Facial recognition analyzes micro-expressions</li>
                    <li>• AI identifies dominant emotional state</li>
                    <li>• Contrarian therapy: opposite music to balance mood</li>
                    <li>• Real Spotify integration plays actual music</li>
                  </ul>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
