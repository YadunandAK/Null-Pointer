import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  const accessToken = request.headers.get("authorization")?.replace("Bearer ", "")
  const { playlistUri, deviceId } = await request.json()

  if (!accessToken) {
    return NextResponse.json({ error: "Access token required" }, { status: 401 })
  }

  try {
    const response = await fetch(`https://api.spotify.com/v1/me/player/play?device_id=${deviceId}`, {
      method: "PUT",
      headers: {
        Authorization: `Bearer ${accessToken}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        context_uri: playlistUri,
      }),
    })

    if (response.status === 204) {
      return NextResponse.json({ success: true })
    } else {
      const error = await response.json()
      return NextResponse.json({ error: error.error?.message || "Failed to play" }, { status: response.status })
    }
  } catch (error) {
    console.error("Spotify play error:", error)
    return NextResponse.json({ error: "Failed to play playlist" }, { status: 500 })
  }
}
