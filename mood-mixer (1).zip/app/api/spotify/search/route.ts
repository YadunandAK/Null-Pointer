import { type NextRequest, NextResponse } from "next/server"
import { spotifyAPI } from "@/lib/spotify"

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url)
  const query = searchParams.get("q")

  if (!query) {
    return NextResponse.json({ error: "Query parameter required" }, { status: 400 })
  }

  try {
    const playlists = await spotifyAPI.searchPlaylists(query)
    return NextResponse.json({ playlists })
  } catch (error) {
    console.error("Spotify search error:", error)
    return NextResponse.json({ error: "Failed to search Spotify" }, { status: 500 })
  }
}
