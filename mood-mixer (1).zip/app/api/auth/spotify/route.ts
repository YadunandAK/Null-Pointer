import { type NextRequest, NextResponse } from "next/server"

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url)
  const code = searchParams.get("code")
  const state = searchParams.get("state")
  const error = searchParams.get("error")

  if (error) {
    return NextResponse.redirect(new URL(`/?error=${error}`, request.url))
  }

  if (!code) {
    // Redirect to Spotify authorization
    const clientId = process.env.NEXT_PUBLIC_SPOTIFY_CLIENT_ID
    const redirectUri = `${process.env.NEXTAUTH_URL || "http://127.0.0.1:3000"}/api/auth/spotify`
    const scope = [
      "streaming",
      "user-read-email",
      "user-read-private",
      "user-read-playback-state",
      "user-modify-playback-state",
      "playlist-read-private",
      "playlist-read-collaborative",
    ].join(" ")

    const authUrl = new URL("https://accounts.spotify.com/authorize")
    authUrl.searchParams.set("response_type", "code")
    authUrl.searchParams.set("client_id", clientId!)
    authUrl.searchParams.set("scope", scope)
    authUrl.searchParams.set("redirect_uri", redirectUri)
    authUrl.searchParams.set("state", "mood-mixer-auth")

    return NextResponse.redirect(authUrl.toString())
  }

  // Exchange code for access token
  try {
    const clientId = process.env.NEXT_PUBLIC_SPOTIFY_CLIENT_ID
    const clientSecret = process.env.SPOTIFY_CLIENT_SECRET
    const redirectUri = `${process.env.NEXTAUTH_URL || "http://127.0.0.1:3000"}/api/auth/spotify`

    const response = await fetch("https://accounts.spotify.com/api/token", {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
        Authorization: `Basic ${Buffer.from(`${clientId}:${clientSecret}`).toString("base64")}`,
      },
      body: new URLSearchParams({
        grant_type: "authorization_code",
        code,
        redirect_uri: redirectUri,
      }),
    })

    const tokens = await response.json()

    if (tokens.error) {
      return NextResponse.redirect(new URL(`/?error=${tokens.error}`, request.url))
    }

    // In a real app, you'd store these tokens securely (database, encrypted cookies, etc.)
    // For demo purposes, we'll redirect with tokens in URL (NOT recommended for production)
    const redirectUrl = new URL("/", request.url)
    redirectUrl.searchParams.set("access_token", tokens.access_token)
    redirectUrl.searchParams.set("refresh_token", tokens.refresh_token)
    redirectUrl.searchParams.set("expires_in", tokens.expires_in.toString())

    return NextResponse.redirect(redirectUrl.toString())
  } catch (error) {
    console.error("Spotify auth error:", error)
    return NextResponse.redirect(new URL("/?error=auth_failed", request.url))
  }
}
